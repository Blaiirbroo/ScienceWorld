# This repo is not going to be worked on anymore, if you are looking to help, go to the [website v2](https://github.com/3kh0/website-v2), if you have questions, hit me up on discord!<br>

# 3kh0.github.io<br>

## Badges<br>

<p>
<img alt="GitHub last commit" src="https://img.shields.io/github/last-commit/3kh0/3kh0.github.io?color=red&label=Lastest%20commit&logo=github">
<img alt="GitHub contributors" src="https://img.shields.io/github/contributors/3kh0/3kh0.github.io?color=purple&label=Contributors&logo=github">
<img alt="GitHub forks" src="https://img.shields.io/github/forks/3kh0/3kh0.github.io?label=Forks&logo=github">
<img alt="GitHub Repo stars" src="https://img.shields.io/github/stars/3kh0/3kh0.github.io?color=yellow&label=Stars&logo=github">
<img alt="GitHub" src="https://img.shields.io/github/license/3kh0/3kh0.github.io?label=License&logo=github">
<img alt="GitHub issues" src="https://img.shields.io/github/issues/3kh0/3kh0.github.io?label=Issues&logo=github">
<img alt="GitHub pull requests" src="https://img.shields.io/github/issues-pr/3kh0/3kh0.github.io?color=yellow&label=Pull%20Requests&logo=github">
  </p>

## What is this?

This is the source code for my website. <br>
Feel free to explore it! <br>
If you need help, you can open a issue [here](https://github.com/3kh0/3kh0.github.io/issues/new)!<br>
I hope this helps!<br>

## Current projects

Currently we are revamping the whole site. We are adding CSS to the page!<br>
You can view the project [here](https://github.com/3kh0/3kh0.github.io/projects/1)!

### Contributors:
> [@Vexify4](https://github.com/Vexify4)

> [@Echo](https://github.com/3kh0)

> [@Orion](https://github.com/the-0r10n)

If you would like to help make a fork and show us what you got!
